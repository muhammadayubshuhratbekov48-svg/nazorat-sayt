from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_socketio import SocketIO
import os

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get("DATABASE_URL","sqlite:///control_app.db")
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = os.environ.get("JWT_SECRET_KEY","super-jwt-secret")
app.config['UPLOAD_FOLDER'] = os.path.join(os.getcwd(), "uploads")
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

CORS(app)
db = SQLAlchemy(app)
jwt = JWTManager(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# import after initialization
import models
import routes_auth, routes_media, routes_admin, routes_update, realtime

app.register_blueprint(routes_auth.bp, url_prefix="/api/auth")
app.register_blueprint(routes_media.bp, url_prefix="/api/media")
app.register_blueprint(routes_admin.bp, url_prefix="/api/admin")
app.register_blueprint(routes_update.bp, url_prefix="/api/update")

# attach socketio handlers
realtime.init_socketio(socketio, app)

@app.route("/")
def home():
    return send_from_directory("templates","index.html")

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    socketio.run(app, host="0.0.0.0", port=5000, debug=True)
