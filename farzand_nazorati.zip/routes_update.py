from flask import Blueprint, jsonify
bp = Blueprint("update", __name__)
CURRENT = "1.0.0"
@bp.route("/check", methods=["GET"])
def check():
    latest = "1.0.1"
    if latest != CURRENT:
        return jsonify({"update_available":True,"latest_version":latest,"download":"https://yourdomain.com/downloads/app.apk"}),200
    return jsonify({"update_available":False}),200
