package uz.farzand.nazorati

import android.Manifest
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.provider.Settings
import android.widget.Toast

class MainActivity: AppCompatActivity() {
    lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val perms = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION)
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){ map ->
        }.launch(perms)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        web.loadUrl("https://yourdomain.com")
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun showToast(msg: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }
        }
        @JavascriptInterface
        fun openSettings() {
            val intent = Intent(Settings.ACTION_SETTINGS)
            startActivity(intent)
        }
    }

    override fun onBackPressed(){
        if(web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
