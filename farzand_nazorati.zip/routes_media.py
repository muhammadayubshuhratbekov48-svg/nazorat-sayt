from flask import Blueprint, request, jsonify, current_app, send_from_directory
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import CameraData, AudioData, LocationData
from app import db, socketio
import os, uuid, base64
from werkzeug.utils import secure_filename

bp = Blueprint("media", __name__)
ALLOWED = {"png","jpg","jpeg","webp","mp4","webm"}

def allowed(filename):
    return "." in filename and filename.rsplit(".",1)[1].lower() in ALLOWED

@bp.route("/upload_camera", methods=["POST"])
@jwt_required()
def upload_camera():
    user = get_jwt_identity()
    if 'file' not in request.files:
        return jsonify({"error":"file missing"}),400
    f = request.files['file']
    if f.filename == "":
        return jsonify({"error":"filename empty"}),400
    if not allowed(f.filename):
        return jsonify({"error":"not allowed type"}),400
    fn = secure_filename(f.filename)
    unique = f"{uuid.uuid4().hex}_{fn}"
    path = os.path.join(current_app.config['UPLOAD_FOLDER'], unique)
    f.save(path)
    cam = CameraData(user_id=user['id'], filename=unique)
    db.session.add(cam); db.session.commit()
    socketio.emit("new_camera", {"user_id":user['id'], "url": f"/api/media/uploads/{unique}"}, broadcast=True)
    return jsonify({"message":"ok","url":f"/api/media/uploads/{unique}"}),200

@bp.route("/uploads/<path:filename>")
def serve_upload(filename):
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], filename)

@bp.route("/send_location", methods=["POST"])
@jwt_required()
def send_location():
    user = get_jwt_identity()
    data = request.get_json() or request.form
    try:
        lat = float(data.get("latitude"))
        lon = float(data.get("longitude"))
    except:
        return jsonify({"error":"invalid coordinates"}),400
    loc = LocationData(user_id=user['id'], latitude=lat, longitude=lon)
    db.session.add(loc); db.session.commit()
    socketio.emit("new_location", {"user_id":user['id'], "lat":lat, "lon":lon}, broadcast=True)
    return jsonify({"message":"ok"}),200

@bp.route("/upload_audio_b64", methods=["POST"])
@jwt_required()
def upload_audio_b64():
    user = get_jwt_identity()
    data = request.get_json()
    b64 = data.get("b64")
    if not b64:
        return jsonify({"error":"no data"}),400
    header, b64data = (b64.split(',',1) if ',' in b64 else (None,b64))
    binary = base64.b64decode(b64data)
    filename = f"{uuid.uuid4().hex}.webm"
    path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
    with open(path, "wb") as f:
        f.write(binary)
    a = AudioData(user_id=user['id'], filename=filename)
    db.session.add(a); db.session.commit()
    socketio.emit("new_audio", {"user_id": user['id'], "url": f"/api/media/uploads/{filename}"}, broadcast=True)
    return jsonify({"message":"ok","url":f"/api/media/uploads/{filename}"}),200
