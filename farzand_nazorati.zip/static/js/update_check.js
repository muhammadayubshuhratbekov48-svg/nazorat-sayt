async function checkForUpdate(){
    try {
        const res = await fetch('/api/update/check');
        const j = await res.json();
        if (j.update_available) {
            document.body.innerHTML = `<div style="background:#111;color:white;display:flex;align-items:center;justify-content:center;height:100vh">
                <div style="text-align:center">
                  <h1>YANGILANISH MAVJUD</h1>
                  <p>Versiya: ${j.latest_version}</p>
                  <a href="${j.download}" target="_blank">Yuklab olish</a>
                </div>
              </div>`;
        }
    } catch(e){ console.error(e); }
}
checkForUpdate();
