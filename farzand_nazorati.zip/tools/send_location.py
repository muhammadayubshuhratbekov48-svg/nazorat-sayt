import requests, time
URL = "http://127.0.0.1:5000/api/media/send_location"
TOKEN = "YOUR_JWT_TOKEN"
while True:
    data = {"latitude":41.3, "longitude":69.25}
    headers = {'Authorization':f'Bearer {TOKEN}'}
    r = requests.post(URL, json=data, headers=headers)
    print(r.status_code, r.text)
    time.sleep(10)
