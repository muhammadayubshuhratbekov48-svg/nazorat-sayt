import cv2, requests, time
URL = "http://127.0.0.1:5000/api/media/upload_camera"
TOKEN = "YOUR_JWT_TOKEN"
cap = cv2.VideoCapture(0)
if not cap.isOpened(): raise SystemExit("Kamera yo'q")
while True:
    ret, frame = cap.read()
    if not ret: break
    fname = "frame.jpg"
    cv2.imwrite(fname, frame)
    files = {'file': open(fname,'rb')}
    headers = {'Authorization':f'Bearer {TOKEN}'}
    r = requests.post(URL, files=files, headers=headers)
    print(r.status_code, r.text)
    time.sleep(5)
