from flask import current_app
from flask_socketio import emit, join_room, leave_room

socketio = None

def init_socketio(sio, app):
    global socketio
    socketio = sio

@socketio.on('connect')
def on_connect():
    emit('server_message', {'msg': 'connected'})

@socketio.on('join_room')
def handle_join(data):
    room = data.get('room')
    join_room(room)
    emit('server_message', {'msg': f'Joined room {room}'}, room=room)

@socketio.on('leave_room')
def handle_leave(data):
    room = data.get('room')
    leave_room(room)
    emit('server_message', {'msg': f'Left room {room}'}, room=room)

@socketio.on('audio_chunk')
def handle_audio_chunk(data):
    user_id = data.get('user_id')
    socketio.emit('admin_audio', data, broadcast=True)
