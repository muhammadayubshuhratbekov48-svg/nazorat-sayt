from flask import Blueprint, jsonify, render_template, request
from models import User, CameraData, LocationData
from app import db
from flask_jwt_extended import jwt_required, get_jwt_identity, create_access_token

bp = Blueprint("admin", __name__)

@bp.route("/login", methods=["POST"])
def admin_login():
    data = request.get_json()
    email = data.get("email"); password = data.get("password")
    u = User.query.filter_by(email=email).first()
    if not u:
        return jsonify({"error":"not found"}),404
    if not u.is_admin:
        return jsonify({"error":"forbidden"}),403
    token = create_access_token(identity={"id":u.id,"email":u.email,"is_admin":True})
    return jsonify({"token":token}),200

@bp.route("/users", methods=["GET"])
@jwt_required()
def users_list():
    me = get_jwt_identity()
    if not me.get("is_admin"):
        return jsonify({"error":"forbidden"}),403
    users = User.query.all()
    out = [{"id":u.id,"email":u.email,"created":u.created_at.isoformat()} for u in users]
    return jsonify(out),200

@bp.route("/latest_camera", methods=["GET"])
def latest_camera():
    c = CameraData.query.order_by(CameraData.timestamp.desc()).first()
    if not c:
        return jsonify({"url":None}),200
    return jsonify({"url":f"/api/media/uploads/{c.filename}"}),200

@bp.route("/latest_location", methods=["GET"])
def latest_location():
    l = LocationData.query.order_by(LocationData.timestamp.desc()).first()
    if not l:
        return jsonify({"latitude":41.311081,"longitude":69.240562}),200
    return jsonify({"latitude":l.latitude,"longitude":l.longitude}),200

@bp.route("/force_update", methods=["POST"])
def force_update():
    from app import socketio
    socketio.emit("force_update", {"message":"Please update to latest version"}, broadcast=True)
    return jsonify({"message":"ok"}),200
