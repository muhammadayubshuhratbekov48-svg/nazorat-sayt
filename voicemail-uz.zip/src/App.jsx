
import React, { useState, useRef, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, Outlet, useNavigate } from 'react-router-dom'

function Layout() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-black/60 backdrop-blur px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-black/70 flex items-center justify-center text-xl font-bold text-white">AV</div>
          <div>
            <h1 className="text-lg font-semibold">Avtojavob tizimi</h1>
            <div className="text-sm text-gray-400">O‘zbekiston uchun — O'zbekcha interfeys</div>
          </div>
        </div>
        <nav>
          <ul className="flex gap-4 items-center">
            <li><Link to="/" className="text-gray-200 hover:underline">Bosh sahifa</Link></li>
            <li><Link to="/messages" className="text-gray-200 hover:underline">Xabarlar</Link></li>
            <li><Link to="/settings" className="text-gray-200 hover:underline">Sozlamalar</Link></li>
            <li><Link to="/about" className="text-gray-200 hover:underline">Haqida</Link></li>
          </ul>
        </nav>
      </header>

      <main className="flex-1 p-6">
        <Outlet />
      </main>

      <footer className="bg-black/50 text-center text-sm text-gray-400 py-3">
        © {new Date().getFullYear()} Avtojavob demo — faqat test maqsadlar uchun
      </footer>
    </div>
  )
}

function Home() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="rounded-2xl bg-gradient-to-br from-gray-800 to-black p-8">
        <h2 className="text-2xl font-bold mb-2">Xush kelibsiz</h2>
        <p className="text-gray-300 mb-4">
          Bu demo sayt orqali siz ovozli pochta xabarlarini yozib, saqlab, eshita olasiz.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-white/5 rounded-lg">
            <h3 className="font-semibold">051 raqamga ulanmagan</h3>
            <p className="text-sm text-gray-400">Qisqa raqam va operator integratsiyasi server tomonda bajarilishi kerak — bu demo faqat frontend.</p>
          </div>

          <div className="p-4 bg-white/5 rounded-lg">
            <h3 className="font-semibold">Mahalliy saqlash</h3>
            <p className="text-sm text-gray-400">Yozib olingan xabarlar brauzerda saqlanadi va oson yuklab olinadi.</p>
          </div>

          <div className="p-4 bg-white/5 rounded-lg">
            <h3 className="font-semibold">SMS (simulyatsiya)</h3>
            <p className="text-sm text-gray-400">Yangi xabar kelganda sayt ichida bildirishnoma ko'rsatiladi va (agar sozlangan bo'lsa) simulyatsiyalangan SMS xabari yaratiladi.</p>
          </div>
        </div>
      </div>
    </div>
  )
}

function Messages() {
  const [messages, setMessages] = useState(() => {
    try {
      const raw = localStorage.getItem('vm_messages_v1')
      return raw ? JSON.parse(raw) : []
    } catch (e) {
      return []
    }
  })
  const [recording, setRecording] = useState(false)
  const [mediaRecorder, setMediaRecorder] = useState(null)
  const [chunks, setChunks] = useState([])
  const [timer, setTimer] = useState(0)
  const timerRef = useRef(null)
  const MAX_MS = 180000
  const [notif, setNotif] = useState(null)

  useEffect(() => {
    localStorage.setItem('vm_messages_v1', JSON.stringify(messages))
  }, [messages])

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
      if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop()
    }
  }, [mediaRecorder])

  function notifySim(msg) {
    setNotif(msg)
    setTimeout(() => setNotif(null), 8000)
  }

  async function startRecording() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      alert('Brauzeringiz audio yozishni qo\'llab-quvvatlamaydi.')
      return
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mr = new MediaRecorder(stream)
      let localChunks = []
      mr.ondataavailable = (e) => {
        if (e.data && e.data.size) localChunks.push(e.data)
      }
      mr.onstop = () => {
        const blob = new Blob(localChunks, { type: 'audio/webm' })
        const url = URL.createObjectURL(blob)
        const id = 'm_' + Date.now()
        const duration = Math.round(timer / 1000)
        const createdAt = new Date().toLocaleString('uz-UZ')
        const entry = { id, displayName: 'Notanish', phoneNumber: '---', duration, createdAt, url, blobName: id + '.webm' }
        setMessages(prev => [entry, ...prev])
        // Simulate SMS notify
        notifySim(`Sizda yangi ovozli habar bor. Tekshirish uchun 051 raqamiga qo'ng'iroq qiling. (${createdAt}, ${duration}s)`)
        setChunks([])
        setTimer(0)
        if (timerRef.current) clearInterval(timerRef.current)
      }
      mr.start()
      setMediaRecorder(mr)
      setChunks([])
      setRecording(true)
      setTimer(0)
      timerRef.current = setInterval(() => {
        setTimer(t => {
          const nt = t + 1000
          if (nt >= MAX_MS) {
            if (mr.state !== 'inactive') mr.stop()
            return MAX_MS
          }
          return nt
        })
      }, 1000)
      setChunks(localChunks)
    } catch (e) {
      alert('Yozishni boshlashda xatolik: ' + e.message)
    }
  }

  function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop()
      mediaRecorder.stream && mediaRecorder.stream.getTracks().forEach(t => t.stop())
      setRecording(false)
    }
  }

  function playMessage(msg) {
    const audio = new Audio(msg.url)
    audio.play()
  }

  function downloadMessage(msg) {
    const a = document.createElement('a')
    a.href = msg.url
    a.download = msg.blobName || 'voicemail.webm'
    document.body.appendChild(a)
    a.click()
    a.remove()
  }

  function deleteMessage(id) {
    if (!confirm('O\'chirilsinmi?')) return
    setMessages(prev => prev.filter(m => m.id !== id))
  }

  function addTestData() {
    const id = 'm_' + Date.now()
    const entry = { id, displayName: 'Sinov', phoneNumber: '+998901234567', duration: 12, createdAt: new Date().toLocaleString('uz-UZ'), url: '', blobName: id + '.webm' }
    setMessages(prev => [entry, ...prev])
    notifySim('Test xabar qo\'shildi.')
  }

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      {notif && <div className="p-3 bg-yellow-600 text-black rounded">{notif}</div>}
      <div className="p-4 bg-white/5 rounded-lg">
        <h3 className="font-semibold text-lg mb-2">Yozuv</h3>
        <p className="text-sm text-gray-400 mb-3">Rekord tugmasini bosing va gapiring. Maksimum 3 daqiqa.</p>
        <div className="flex items-center gap-3">
          <button
            onClick={() => { if (!recording) startRecording(); else stopRecording() }}
            className={`px-4 py-2 rounded ${recording ? 'bg-red-600' : 'bg-green-500'} font-semibold`}
          >
            {recording ? 'To‘xtatish' : 'Yozishni boshlash'}
          </button>

          <div className="px-3 py-2 bg-black/40 rounded">
            Timer: <strong>{Math.floor(timer/1000)}s</strong>
          </div>

          <button onClick={addTestData} className="px-3 py-2 bg-indigo-600 rounded">Test xabar</button>
        </div>
      </div>

      <div className="p-4 bg-white/5 rounded-lg">
        <h3 className="font-semibold text-lg mb-2">Xabarlar</h3>
        {messages.length === 0 ? (
          <p className="text-gray-400">Hozircha xabarlar mavjud emas.</p>
        ) : (
          <ul className="space-y-3">
            {messages.map(m => (
              <li key={m.id} className="p-3 bg-black/40 rounded flex items-center justify-between">
                <div>
                  <div className="font-medium">{m.displayName}</div>
                  <div className="text-xs text-gray-400">{m.phoneNumber} • {m.duration ? m.duration + 's' : '—'} • {m.createdAt}</div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => playMessage(m)} className="px-2 py-1 bg-green-600 rounded text-sm">Tinglash</button>
                  <button onClick={() => downloadMessage(m)} className="px-2 py-1 bg-blue-600 rounded text-sm">Yuklab olish</button>
                  <button onClick={() => deleteMessage(m.id)} className="px-2 py-1 bg-red-600 rounded text-sm">O'chirish</button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}

function Settings() {
  const [phone, setPhone] = useState(() => localStorage.getItem('vm_phone') || '')
  const [smsEnabled, setSmsEnabled] = useState(() => (localStorage.getItem('vm_sms') || 'true') === 'true')
  const [theme, setTheme] = useState(() => localStorage.getItem('vm_theme') || 'dark')

  useEffect(() => {
    localStorage.setItem('vm_phone', phone)
  }, [phone])
  useEffect(() => {
    localStorage.setItem('vm_sms', smsEnabled ? 'true' : 'false')
  }, [smsEnabled])
  useEffect(() => {
    localStorage.setItem('vm_theme', theme)
  }, [theme])

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <div className="p-4 bg-white/5 rounded-lg">
        <h3 className="font-semibold">Sozlamalar</h3>
        <div className="mt-3 space-y-2">
          <label className="block">
            Telefon raqami:
            <input className="mt-1 w-full rounded px-3 py-2 bg-black/60" placeholder="+99890..." value={phone} onChange={(e)=>setPhone(e.target.value)} />
          </label>

          <label className="flex items-center gap-2">
            <input type="checkbox" checked={smsEnabled} onChange={(e)=>setSmsEnabled(e.target.checked)} />
            SMS bildiruvlarini yoqish (simulyatsiya)
          </label>

          <label className="block">
            Mavzu:
            <select value={theme} onChange={(e)=>setTheme(e.target.value)} className="mt-1 bg-black/60 rounded px-2 py-2">
              <option value="dark">Qora</option>
              <option value="light">Oq</option>
            </select>
          </label>

          <div className="mt-3">
            <button onClick={()=>alert('Saqlandi (localStorage)')} className="px-3 py-2 bg-green-500 rounded">Saqlash</button>
          </div>
        </div>
      </div>

      <div className="p-4 bg-white/5 rounded-lg">
        <h3 className="font-semibold">Qisqacha ma'lumot</h3>
        <p className="text-sm text-gray-400">Bu demo frontend. Qisqa raqam (051), operator yo'naltirish va SMS integratsiyasi server tomonda amalga oshiriladi.</p>
      </div>
    </div>
  )
}

function About() {
  return (
    <div className="max-w-3xl mx-auto">
      <div className="p-4 bg-white/5 rounded-lg">
        <h3 className="font-semibold">Haqida</h3>
        <p className="text-sm text-gray-400">
          Ushbu loyiha O‘zbekiston uchun o‘zbek tilidagi ovozli pochta (voicemail / autoresponder) demo frontendidir.
          Backend, VoIP va operator bilan integratsiya real tizimga aylantirish uchun talab qilinadi.
        </p>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="messages" element={<Messages />} />
          <Route path="settings" element={<Settings />} />
          <Route path="about" element={<About />} />
        </Route>
      </Routes>
    </Router>
  )
}
