
function startMonitoring() {
  alert("Nazorat boshlandi! Endi siz farzandingizni kuzatishingiz mumkin.");
}
